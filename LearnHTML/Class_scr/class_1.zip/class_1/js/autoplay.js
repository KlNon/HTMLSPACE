var multiImages = document.getElementById("images");
var circles = document.getElementById("btns").getElementsByTagName("span");
var box = document.getElementById("box_autoplay");
var currentIndex = 0;
var preIndex = 0;
var timer = null;

for (let i = 0; i < circles.length; i++) {
    circles[i].style.backgroundColor="rgb(88, 186, 231)";
    circles[i].setAttribute("id", i);
    circles[i].addEventListener("mouseenter", overCircle);
}
timer = setInterval(nextMove, 3000);
box.addEventListener("mouseover", function () {
    clearInterval(timer);
});
box.addEventListener("mouseout", function () {
    timer = setInterval(nextMove, 3000);
});
changeCircleColor(preIndex, currentIndex);



function overCircle() {
    preIndex = currentIndex;
    currentIndex = parseInt(this.id);
    // multiImages.style.transition="1.5s";
    changeCircleColor(preIndex, currentIndex);
    moveImage();
}

function changeCircleColor(preIndex, currentIndex) {
    circles[preIndex].style.backgroundColor="rgb(88, 186, 231)";
    circles[currentIndex].style.backgroundColor="rgb(255, 165, 0)";
}

function preMove() {
    preIndex = currentIndex;
    if (currentIndex != 0) {
        currentIndex--;
        // multiImages.style.transition="1s";
    }
    else {
        currentIndex = 4;
        // multiImages.style.transition="0.5s";
    }
    changeCircleColor(preIndex, currentIndex);
    moveImage();
}

function nextMove() {
    preIndex = currentIndex;
    if (currentIndex != 4) {
        currentIndex++;
        // multiImages.style.transition="1s";
    }
    else {
        currentIndex = 0;
        // multiImages.style.transition="0.5s";
    }
    changeCircleColor(preIndex, currentIndex);
    moveImage();
}

function moveImage() {
    multiImages.style.left = -currentIndex * 900 + "px";
}